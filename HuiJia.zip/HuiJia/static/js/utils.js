function sayHello(){
  console.log("你好，我是工具类");
}

window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());

gtag('config', 'G-WDMVX87J6G');